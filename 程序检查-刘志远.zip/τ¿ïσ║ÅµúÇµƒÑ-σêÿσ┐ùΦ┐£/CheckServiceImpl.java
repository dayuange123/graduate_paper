package cn.xupt.teach.teachback.service.impl;

import cn.xupt.teach.teachback.bean.BlockContent;
import cn.xupt.teach.teachback.bean.LineContent;
import cn.xupt.teach.teachback.bean.WorkEnum;
import cn.xupt.teach.teachback.bean.WorkResult;
import cn.xupt.teach.teachback.exception.TeachException;
import cn.xupt.teach.teachback.orc.WebOcr;
import cn.xupt.teach.teachback.service.CheckHistoryService;
import cn.xupt.teach.teachback.service.CheckService;
import cn.xupt.teach.teachback.service.ErrorContainerService;
import cn.xupt.teach.teachback.service.ErrorHistoryService;
import cn.xupt.teach.teachback.util.Utils;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static cn.xupt.teach.teachback.util.Constants.CONFIDENCE_THRESHOLD;
import static cn.xupt.teach.teachback.util.Constants.FILE_BASE_PATH;

/**
 * Author: liuzhiyuan
 * Date: 2020/3/29
 * Description:
 */
@Component("checkService")
@Slf4j
public class CheckServiceImpl implements CheckService {

    @Resource(name = "evalVisitorImpl")
    private EvalVisitorImpl evalVisitor;

    @Resource(name = "errorContainerService")
    private ErrorContainerService errorContainerService;

    @Resource(name = "checkHistoryService")
    private CheckHistoryService checkHistoryService;

    @Resource(name = "errorHistoryService")
    private ErrorHistoryService errorHistoryService;

    @Override
    public Integer checkWorkByImage(MultipartFile file, Integer id) throws TeachException, IOException, ParseException {
        if (file.isEmpty()) {
            throw new TeachException("file is empty");
        }
        String filePath = uploadImage(file);
        String discernRes = WebOcr.getImageDiscernResByAbsoluteUrl(filePath);
        JSONObject res = (JSONObject) JSONObject.parse(discernRes);
        if (res.get("code").equals("0")) {
            if (res.get("data") == null) {
                return -1;
            }
            JSONObject data = (JSONObject) res.get("data");
            JSONArray jsonArray = (JSONArray) data.get("block");
            if (jsonArray == null) {
                return -1;
            }
            List<BlockContent> blockContents = jsonArray.toJavaList(BlockContent.class);
            if (blockContents == null) {
                return -1;
            }
            List<WorkResult> workResults = calculateHandler(blockContents, id);
            //加入检查历史
            Integer workResultId = checkHistoryService.addCheck(id, workResults,
                filePath.replaceAll(FILE_BASE_PATH, ""), WorkEnum.IMAGE_CHECK.getCode());
            //加入错误历史
            errorHistoryService.addError(id, workResults, WorkEnum.IMAGE_CHECK.getCode());
            return workResultId;
        } else {
            throw new TeachException("get image res fail,code=" + res.get("code").toString());
        }
    }


    private List<WorkResult> calculateHandler(List<BlockContent> blockContents, Integer id) {
        List<WorkResult> resList = new ArrayList<>();
        for (BlockContent blockContent : blockContents) {
            if (blockContent.getType().equals("text")) {
                List<LineContent> line = blockContent.getLine();
                line.forEach(lineContent -> {
                    if (lineContent.getConfidence() >= CONFIDENCE_THRESHOLD) {
                        lineContent.getWord().forEach(content -> {
                            WorkResult workResult = calculateCore(content.getContent(), id);
                            if (workResult != null) {
                                resList.add(workResult);
                            }
                        });
                    }
                });
            }
        }
        return resList;
    }

    private WorkResult calculateCore(String content, Integer id) {
        //矫正
        content = correctContent(content);
        WorkResult workResult = new WorkResult();
        workResult.setSourceStr(content);
        //转换×÷ 为*/
        content = Utils.changeDivAndMut(true, content);
        String[] split = content.split("=");
        if (split.length == 0) {
            return null;
        }
        //获得答案
        String s = Utils.changeDivAndMut(false, split[0]);
        if (split.length == 1) {
            Integer val = evalVisitor.getVal(split[0]);
            workResult.setTargetStr(s + "=" + val);
            workResult.setIsCorrect(false);
        } else {
            Integer val = evalVisitor.getVal(split[0]);
            workResult.setIsCorrect(String.valueOf(val).equals(split[1]));
            workResult.setTargetStr(s + "=" + val);
        }
        // 错题进入错题库。
        if (!workResult.getIsCorrect()) {
            errorContainerService.addErrorWork(s, id);
        }
        return workResult;
    }

    /**
     * 如果有= ，并且有后面的数组 说明是 检查作业
     * 否则为生成答案
     *
     * @param content
     * @return
     */
    private String correctContent(String content) {
        if (content.contains("Z") || content.contains("z")) {
            content = content.replaceAll("Z", "2");
            content = content.replaceAll("z", "2");
        }
        if (content.contains("O") || content.contains("o")) {
            content = content.replaceAll("O", "0");
            content = content.replaceAll("o", "0");
        }
        if (content.contains("L") || content.contains("l")) {
            content = content.replaceAll("L", "1");
            content = content.replaceAll("l", "1");
        }
        if (content.contains("T")) {
            content = content.replaceAll("T", "7");
        }
        return content;

    }


    /**
     * @return
     */

    /**
     * 上传作为文件到本地
     *
     * @param file
     * @return
     * @throws TeachException
     */
    private String uploadImage(MultipartFile file) throws TeachException {
        String originUrl = Objects.requireNonNull(file.getOriginalFilename()).
            substring(file.getOriginalFilename().lastIndexOf("."));
        String filePath = FILE_BASE_PATH + "workImage/" + Utils.getIconUrl(originUrl);
        log.info("get file path ={}", filePath);
        try {
            File baseFile = new File(FILE_BASE_PATH + "workImage");
            if (!baseFile.exists()) {
                if (!baseFile.mkdirs()) {
                    log.error("create base file fail, file path={}", FILE_BASE_PATH + "workImage");
                    throw new TeachException("create base file fail");
                }
            }
            File file1 = new File(filePath);
            System.out.println(file1.getAbsolutePath());
            file.transferTo(file1);
            return filePath;
        } catch (IOException e) {
            e.printStackTrace();
            log.error("upload file error");
            throw new TeachException("file upload fail");
        }
    }





    @Override
    public Integer checkWorkByText(List<String> workList, Integer id) throws TeachException {
        if(workList==null){
            return -1;
        }
        List<WorkResult> workResults = workList.stream().map(w -> calculateCoreByText(w, id))
            .collect(Collectors.toList());
        errorHistoryService.addError(id, workResults, WorkEnum.PRACTICE_CHECK.getCode());
        return checkHistoryService.addCheck(id, workResults, "", WorkEnum.PRACTICE_CHECK.getCode());
    }


    private WorkResult calculateCoreByText(String content, Integer id) {
        String normContent = Utils.changeDivAndMut(true, content);
        String[] normContentArray = normContent.split("=");
        String[] contentArray = content.split("=");

        WorkResult workResult = new WorkResult();
        workResult.setSourceStr(content);
        if (normContentArray.length == 0) {
            return null;
        }
        //获得答案
        if (normContentArray.length == 1) {
            Integer val = evalVisitor.getVal(normContentArray[0]);
            workResult.setTargetStr(contentArray[0] + "=" + val);
            workResult.setIsCorrect(false);
        } else {
            Integer val = evalVisitor.getVal(normContentArray[0]);
            workResult.setIsCorrect(String.valueOf(val).equals(normContentArray[1]));
            workResult.setTargetStr(contentArray[0] + "=" + val);
        }
        // 错题进入错题库。
        if (!workResult.getIsCorrect()) {
            errorContainerService.addErrorWork(contentArray[0], id);
        }
        return workResult;
    }
}
